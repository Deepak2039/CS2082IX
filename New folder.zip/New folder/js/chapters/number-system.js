// Number System Chapter Specific JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Number System chapter loaded');
    
    // Initialize the MCQs for this chapter
    if (typeof initMCQSections === 'function') {
        initMCQSections();
    }
});
